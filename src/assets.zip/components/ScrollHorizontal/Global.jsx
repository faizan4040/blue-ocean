import React from 'react'

function Global() {
  return (
    <div>
      <h1>Global</h1>
    </div>
  )
}

export default Global
