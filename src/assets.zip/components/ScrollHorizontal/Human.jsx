import React from 'react'

function Human() {
  return (
    <div>
      <h1>Human</h1>
    </div>
  )
}

export default Human
