import React from 'react'

function Highly() {
  return (
    <div>
      <h1>Highl</h1>
    </div>
  )
}

export default Highly
