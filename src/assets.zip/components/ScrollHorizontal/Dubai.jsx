import React from 'react'

function Dubai() {
  return (
    <div>
      <h1>Dubai</h1>
    </div>
  )
}

export default Dubai
