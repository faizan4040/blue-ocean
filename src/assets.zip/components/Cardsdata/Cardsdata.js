import Consulting from "../../assets/Consulting.jpg"
import Conference from "../assets/Conference.jpg"
import Training from "../assets/Training.jpg"


export const Helping = [
    {
        img: Consulting, 
        title: "Consulting", 
        body:"MORE DETAILS >"
    },

    {
        img: Conference, 
        title: "Conference", 
        body:"MORE DETAILS >"
    },

    {
        img: Training, 
        title: "Training", 
        body:"MORE DETAILS >"
    },
]